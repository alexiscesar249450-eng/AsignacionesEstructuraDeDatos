package implementaciones;

import excepciones.BolsaException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BolsaGenTest {

    @Test
    public void testConstructor_CapacidadNegativa_LanzaExcepcion() {
        assertThrows(BolsaException.class, () -> new BolsaGen<>(-5));
    }

    @Test
    public void testAgregar_FuncionaCorrectamente() {
        BolsaGen<String> bolsa = new BolsaGen<>(3);
        bolsa.agregar("Manzana");
        assertEquals(1, bolsa.numElementos());
        assertFalse(bolsa.estaVacia());
    }

    @Test
    public void testAgregar_BolsaLlena_LanzaExcepcion() {
        BolsaGen<String> bolsa = new BolsaGen<>(1);
        bolsa.agregar("Manzana"); 
        assertThrows(BolsaException.class, () -> bolsa.agregar("Pera"));
    }

    @Test
    public void testBuscar_ElementoExistente_RetornaElemento() {
        BolsaGen<String> bolsa = new BolsaGen<>(3);
        bolsa.agregar("Manzana");
        bolsa.agregar("Pera");
        assertEquals("Pera", bolsa.buscar("Pera"));
    }

    @Test
    public void testEliminar_ElementoExistente_RetornaTrueYActualizaTamaño() {
        BolsaGen<String> bolsa = new BolsaGen<>(3);
        bolsa.agregar("Manzana");
        bolsa.agregar("Naranja");
        bolsa.agregar("Pera");
        assertTrue(bolsa.eliminar("Naranja"));
        assertEquals(2, bolsa.numElementos());
        assertNull(bolsa.buscar("Naranja")); // Verifica que ya no está
    }

    @Test
    public void testEstaVacia_ConBolsaVacia_RetornaTrue() {
        BolsaGen<String> bolsa = new BolsaGen<>(5);
        assertTrue(bolsa.estaVacia());
    }
}