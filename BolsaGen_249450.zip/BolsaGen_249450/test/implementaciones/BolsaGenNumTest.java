package implementaciones;

import excepciones.BolsaException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BolsaGenNumTest {

    @Test
    public void testSuma_FuncionaCorrectamente() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        bolsa.agregar(10.0);
        bolsa.agregar(20.0);
        bolsa.agregar(30.0);
        assertEquals(60.0, bolsa.suma(), 0.01);
    }

    @Test
    public void testSuma_BolsaVacia_LanzaExcepcion() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        assertThrows(BolsaException.class, () -> bolsa.suma());
    }

    @Test
    public void testPromedio_FuncionaCorrectamente() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        bolsa.agregar(10.0);
        bolsa.agregar(20.0);
        bolsa.agregar(30.0);
        assertEquals(20.0, bolsa.promedio(), 0.01);
    }

    @Test
    public void testPromedio_BolsaVacia_LanzaExcepcion() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        assertThrows(BolsaException.class, () -> bolsa.promedio());
    }

    @Test
    public void testMayores_FuncionaCorrectamente() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        bolsa.agregar(10.0);
        bolsa.agregar(20.0);
        bolsa.agregar(30.0);
        // El promedio es 20.0, solo 30.0 es mayor
        assertEquals(1, bolsa.mayores());
    }

    @Test
    public void testMayores_BolsaVacia_LanzaExcepcion() {
        BolsaGenNum<Double> bolsa = new BolsaGenNum<>(5);
        assertThrows(BolsaException.class, () -> bolsa.mayores());
    }
}