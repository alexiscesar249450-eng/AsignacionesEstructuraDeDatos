package implementaciones;

import excepciones.BolsaException;

public class BolsaGen<T> {

    T[] elementos;
    private int numElementos;
    private final int capacidad;

    // Constructor de la bolsa
    public BolsaGen(int capacidad) {
        if (capacidad <= 0) {
            throw new BolsaException("La capacidad de la bolsa debe ser un número positivo.");
        }
        this.capacidad = capacidad;
        // Se crea el arreglo de Object y se convierte a tipo T
        this.elementos = (T[]) new Object[capacidad];
        this.numElementos = 0;
    }

    // Agrega un elemento a la bolsa
    public void agregar(T nuevoElemento) {
        if (estaLlena()) {
            throw new BolsaException("La bolsa está llena, no se pueden agregar más elementos.");
        }
        elementos[numElementos] = nuevoElemento;
        numElementos++;
    }

    // Busca un elemento y devuelve el objeto encontrado, o null si no existe
    public T buscar(T elemento) {
        for (int i = 0; i < numElementos; i++) {
            if (elementos[i].equals(elemento)) {
                return elementos[i];
            }
        }
        return null;
    }
    
    // Elimina un elemento y devuelve true si lo encuentra, false si no
    public boolean eliminar(T elemento) {
        for (int i = 0; i < numElementos; i++) {
            if (elementos[i].equals(elemento)) {
                // Mueve los elementos para llenar el espacio
                for (int j = i; j < numElementos - 1; j++) {
                    elementos[j] = elementos[j + 1];
                }
                elementos[numElementos - 1] = null; // Borra la referencia del último elemento
                numElementos--;
                return true;
            }
        }
        return false;
    }

    // Métodos para el estado de la bolsa
    public boolean estaVacia() {
        return numElementos == 0;
    }

    public boolean estaLlena() {
        return numElementos == capacidad;
    }

    public int numElementos() {
        return numElementos;
    }
}