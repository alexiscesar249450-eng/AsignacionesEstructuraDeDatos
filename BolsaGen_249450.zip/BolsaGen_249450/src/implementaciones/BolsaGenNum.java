package implementaciones;

import excepciones.BolsaException;

public class BolsaGenNum<T extends Number> extends BolsaGen<T> {

    public BolsaGenNum(int tamano) {
        super(tamano);
    }

    public double suma() throws BolsaException {
        if (estaVacia()) {
            throw new BolsaException("La bolsa está vacía, no se puede calcular la suma.");
        }
        double sum = 0.0;
        for (int i = 0; i < numElementos(); i++) {
            // El método doubleValue() es de la clase Number
            sum += buscar(super.elementos[i]).doubleValue();
        }
        return sum;
    }

    public double promedio() throws BolsaException {
        if (estaVacia()) {
            throw new BolsaException("La bolsa está vacía, no se puede calcular el promedio.");
        }
        return suma() / numElementos();
    }

    public int mayores() throws BolsaException {
        if (estaVacia()) {
            throw new BolsaException("La bolsa está vacía, no se puede calcular el número de mayores al promedio.");
        }
        double avg = promedio();
        int count = 0;
        for (int i = 0; i < numElementos(); i++) {
            if (buscar(super.elementos[i]).doubleValue() > avg) {
                count++;
            }
        }
        return count;
    }
}
