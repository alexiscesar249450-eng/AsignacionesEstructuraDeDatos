package excepciones;

public class BolsaException extends RuntimeException {

    // Constructor vacío
    public BolsaException() {
        super();
    }

    // Constructor con parámetro String
    public BolsaException(String s) {
        super(s);
    }
}
